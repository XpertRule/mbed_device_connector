var xriot = {

	settings: {
		url: "dm.xpertrule.com",
		port: 8001,
		timeout: 5000,
		success: null,
		error: null
	},

	_urlCall: function(url, type, data, timeout, callback) {
		var self = this;
		if (url.substr(0, 1) != "/") {
			url = "/" + url;
		}
		$.ajax({
			url: "php/iot.php",
			type: "POST",
			data: JSON.stringify({
				url: "http://" + self.settings.url + ":" + self.settings.port + url,
				type: type,
				headers: {},
				timeout: timeout,
				data: data
			}),
			cache: false,
			dataType: "JSON",
			success: function(d) {
				if (d.status.toLowerCase() == "ok") {
					callback(JSON.parse(d.data));
				} else {
					callback({status: "error", error: d.error});
				}
			},
			error: function(xhr) {
				callback({status: "error", error: "Cannot connect to IoT prototype connector"});
			}
		});
	},

	// get all the values for passed resources
	read: function(settings) {
		var self = this;

		self.settings.resources = settings.resources;
		self.settings.success = settings.success;
		self.settings.error = settings.error;

		if (self.settings.resources.length == 0) {
			self.settings.success();
			return;
		}

		var nRemaining = self.settings.resources.length;
		var hasError = false;
		for (var c = 0; c < self.settings.resources.length; c++) {
			var resource = self.settings.resources[c];
			delete resource.status;
			delete resource.value;
			delete resource.age;
			delete resource.error;
			(function(resource) {
				self._urlCall(
					resource.url,
					"GET",
					null,
					self.settings.timeout,
					function(result) {
						for (var p in result) {
							resource[p] = result[p];
						}
						if (resource.status.toLowerCase() != "ok") {
							hasError = true;
						}
						nRemaining--;
						if (nRemaining == 0) {
							// complete CB
							if (hasError) {
								self.settings.error();
							} else {
								self.settings.success();
							}
						}
					}
				);
			})(resource);
		}
	},

	// write a value
	write: function(settings) {
		var self = this;
		self._urlCall(
			settings.url + "/",
			"PUT",
			settings.value,
			self.settings.timeout,
			function(result) {
				if (result.status.toLowerCase() == "ok") {
					settings.success();
				} else {
					settings.error(result.error);
				}
			}
		);
	}

};

// --------------------------------
// global XR functions
// --------------------------------
function IOTsetupConnection(settings) {
    xriot.settings.url = settings.url;
    xriot.settings.port = settings.port;
	xriot.settings.timeout = settings.timeout;
	xriot.settings.capture = settings.prototypeCapture;
}

function IOTreadInputs(atts, okAtt) {
	var result;
	replayStack.CriticalSection(
		function(rs) {
			var resource_list = [];
			var c;
			for (c = 0; c < atts.length; c++) {
				resource_list.push({
					url: atts[c].prop("url"),
					type: atts[c].aType == TYPE_NUMERIC ? "num" : "string",
					att: atts[c]
				});
			}
			if (!xriot.settings.capture) {
				xriot.read({
					resources: resource_list,
					success: function() {
						rs.CriticalDone({ok: true, list: resource_list});
					},
					error: function() {
						rs.CriticalDone({ok: false, list: resource_list});
					}
				});
			} else {
				var h = "<table width='100%' border='0' id='mbed_dummy_input_table'>";
				for (c = 0; c < resource_list.length; c++) {
					h += "<tr><td>" + resource_list[c].att.aName + "</td><td>";
					switch (resource_list[c].type) {
						case "num":
							h += "<input class='mbed-dummpy-input' idx='" + c + "' placeholder='Enter a number' />";
							break;
						case "string":
							h += "<input class='mbed-dummpy-input' idx='" + c + "' placeholder='Enter some text' />";
							break;
					}
					h += "</td></tr>";
				}
				h += "</table>";
				xrkb.msgbox({
					type: "OK",
					body: h,
					header: "Supply Input Values",
					width: 420,
					hideCloseBtn: true,
					ok_callback: function() {
						// populate resource_list
						$("#mbed_dummy_input_table").find(".mbed-dummpy-input").each(function() {
							var $this = $(this);
							var c = parseInt($this.attr("idx"), 10);
							var v;
							switch (resource_list[c].type) {
								case "num":
									v = parseFloat($this.val());
									if (isNaN(v)) {
										v = PSEUDO_VALUE_EMPTY;
									}
									break;
								case "string":
									v = $this.val();
									break;
							}
							resource_list[c].value = v;
						});
						rs.CriticalDone({ok: true, list: resource_list});
					}
				});
			}
		}, function(asyncResult) {
			result = asyncResult;
		}
	);

	var c;
	if (!result.ok) {
		okAtt.val(false);
		// Debug individual errors
		for (c = 0; c < result.list.length; c++) {
			if (result.list[c].status != "ok") {
				console.log("Async read of [" + result.list[c].att.aName + "] error: " + result.list[c].error);
			}
		}
	} else {
		for (c = 0; c < result.list.length; c++) {
			result.list[c].att.val(result.list[c].value);
		}
		okAtt.val(true);
	}
}

function IOTwriteOutputs(atts) {
	replayStack.CriticalSection(
		function(rs) {
			function success() {
			}
			function error(err) {
				console.log("Async write error: " + err);
			}
			var c;
			if (!xriot.settings.capture) {
				for (c = 0; c < atts.length; c++) {
					xriot.write({
						url: atts[c].prop("url"),
						value: atts[c].val().toString(),
						success: success,
						error: error
					});
				}
				rs.CriticalDone();
			} else {
				var h = "<table width='100%' border='0' id='mbed_dummy_input_table'>";
				for (c = 0; c < atts.length; c++) {
					h += "<tr><td>" + atts[c].aName + "</td><td>" + atts[c].val().toString() + "</td></tr>";
				}
				h += "</table>";
				xrkb.msgbox({
					type: "OK",
					icon: "info",
					body: h,
					header: "Write Output Values",
					width: 420,
					ok_callback: function() {
						rs.CriticalDone();
					}
				});
			}
		}
	);
}
